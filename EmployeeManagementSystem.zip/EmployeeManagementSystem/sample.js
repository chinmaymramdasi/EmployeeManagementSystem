
let obj={
        status: [
        "Complete"
        ],
        platform: ["Web","APP"
        ],
        domain: ["a"],
        startDate: "03/22/2022",
        endDate: "03/27/2022",
        softLaunch: "",
        abc:"abc"
      }


let whereCondition = ''
Object.keys(obj).forEach(function(item){
  let value = obj[item]
  if(typeof(value)=='object' && value.length > 0){
   let val=value.map((data)=>`'${data}'`)
   whereCondition +=  `${item} in (${val}) and `
  }
  else if (typeof(value)=='string' && value!="")
  {
    whereCondition +=  `${item} = '${value}' and `
  } 
 } )  

 whereCondition = whereCondition.slice(0, -5)

let sql=`select *from sample where ${whereCondition}`
console.log(sql)


/*
let obj={
  "status": [
  "Complete"
  ],
  "platform": [
  "asda",
  ],
  "domain": ["a"],
  "startDate": "03/22/2022",
  "endDate": "",
  "softLaunch": ""
  }
*/



var sample="Android,Ios,Desktop"


const arr=sample.split(',')

console.log(arr)

const on = {
  "firstName": "John",
  "lastName": "Smith",
  "isAlive": "true",
  "age": "25"
};

const objToArray= on =>{
  var keys=Object.keys(on)
  var arr=[]

  for(let i=0;i<keys.length;i++)
  {
    arr.push(on[keys[i]])
  }
  return arr
}

console.log(objToArray(on))


var a=[
  { Name: 'John' },
  { countryName: 'US' },
  { subjectName: 'JavaScript' },
  { teacherName: 'Mike' }
]

const arrObject=a.flat();

console.log("Array",arrObject)

a.map(function(item){
  console.log(item)
  item.Name=Object.values(item.Name)
  console.log(item.Name)
})

