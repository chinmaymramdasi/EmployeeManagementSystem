
var { expressjwt: jwt } = require("express-jwt");
//const { secret } = require('../config.json');


module.exports = authorize;

//let config = "test!212"
function authorize(roles = []) {
    // roles param can be a single role string (e.g. Role.User or 'User') 
    // or an array of roles (e.g. [Role.Admin, Role.User] or ['Admin', 'User'])
    if (typeof roles === 'string') {
        roles = [roles];
    }

    return [
        // authenticate JWT token and attach user to request object (req.user)
        jwt({ secret: "test!212", algorithms: ['HS256'] }),

        // authorize based on user role
        (req, res, next) => {
            if (roles.length && !roles.includes(req.body.role)) {
                // user's role is not authorized
                console.log("Role", req.body.user)
                return res.status(401).json({ message: 'Unauthorized' });
            }

            // authentication and authorization successful
            next();
        }
    ];
}



/*
const jwt = require("jsonwebtoken")
const jwtSecret = "test!212";
module.exports = (req, res, next) => {
    const token = req.body.token || req.query.token || req.headers["x-access-token"]
    if (!token) { return res.status(404).send({ success: false, message: "Un authorized" }) }
    try {
        const decoded = jwt.verify(token, jwtSecret)
        req.user = decoded
        return next()
    }
    catch (err) {
        return res.status(401).send({ success: false, message: err.message })
    }

}
*/