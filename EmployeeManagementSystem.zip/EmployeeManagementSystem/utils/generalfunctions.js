//import db from "../connection/db.connect";

function viewObj(subdata)
  {
    var container={}
    container.EmployeeID=subdata.employeeID
    container.Designation=subdata.designation
    return container
  }

  function viewEmployeeList(subdata)
  {
    let obj={}
    obj.EmployeeID=subdata.EmployeeID
    obj.EmployeeName=subdata.EmployeeName
    return obj
  }

  let container={}

 
  let viewDomainEmployeeList=(subdata)=>container.EmployeeName=subdata.EmployeeName

  let viewProjectList=(subdata)=>container.projectassigned=subdata.ProjectName

    
  
  let viewEmployeeListDetails=(subdata)=>container.employeeName=subdata.EmployeeName

  const getDetails=async (data)=>{
    let array=[]
      let view={}
    for(let subdata of data)
          {
            var index=array.findIndex(function(results){
              return results.name==subdata.employeeName
            })
            
            if(index>-1)
            {
              view=viewObj(subdata)
              array[index]['data'].push(view)
            }
            else
            {
              view=viewObj(subdata)
              array.push({
                'name':subdata.employeeName,
                'data':[view]
              })
            }
          }
        console.log(array)
        return array
  }

//dynamic query to fetch multiple employeeID
  function generateWhereQuery(employeeID) {
    let whereCondition = "";
       if (typeof employeeID == "object") {
            whereCondition += `employee.EmployeeID in (${employeeID}) and `;
        } else {
            whereCondition += `employee.EmployeeID = '${employeeID}' and `;
        }
    
    if (whereCondition != "") whereCondition = `where ${whereCondition}`;
    console.log('Where:',whereCondition)
    return whereCondition.slice(0, -4);
}

module.exports={
    viewObj,
    viewEmployeeList,
    viewEmployeeListDetails,
    getDetails,
    viewDomainEmployeeList,
    generateWhereQuery,
    viewProjectList
}