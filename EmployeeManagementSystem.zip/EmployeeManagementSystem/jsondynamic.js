
let obj={
  "status": [
  "Complete"
  ],
  "platform": [
  "asda",
  ],
  "domain": ["a"],
  "startDate": "03/22/2022",
  "endDate": "",
  "softLaunch": ""
  }

  