let dat = {
    "expStatus": [
    "Complete"
    ],
    "expPlatform": [
    "Desktop",
    "Ios",
    "Mobile Web",
    "Android"
    ],
    "expDomain": "",
    "startDate": "02/01/2022",
    "expEndDate": "",
    "expSoftLaunch": "",
    "favouriteFlag": 0
    }
    let whereClause = {}
    
    
    
    // expPlatformIos, expPlatoformAndroid, expPlatformMobileWeb, expPlatformDesktop
    
    
    
    for(let d in dat){
    // console.log('keys', d)
    // console.log(dat !== '')
    if((typeof(dat[d]) == 'object' && dat[d].length > 0) || (typeof(dat[d]) == 'string' && dat[d] != ''))
    {
        console.log('is platform',d, d.includes('Platform'))
        if(d.includes('Platform')){
        dat[d].map(subData => {
        whereClause[`${d}${subData.split(" ").join("")}`] = 1
        })
        } else {
        whereClause[d] = dat[d]
        }   
    }
    }
    
    console.log('where', whereClause)