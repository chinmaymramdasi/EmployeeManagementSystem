/*
Note:
-All routes for the features will be routed to index.js file 
-For the specific routes for each feature it will be routed to specific feature's route file.
-controller is used for business logic and from the controller only will add the query 
and send back the API response.
*/


const express = require("express")
const db = require('./connection/db.connect');

var app = express();

const PORT = 5000
const bodyParser = require("body-parser");


var employeeRoutes = require("./routes/employee.routes")

var projectRoutes = require("./routes/projects.routes")
var domainRoutes = require("./routes/domain.routes")
var usersRoutes = require("./routes/users.routes")
//var filterRouters=require("./routes/filter.routes")
app.use(bodyParser.json());

app.use("/users", usersRoutes)
app.use("/projects", projectRoutes)
//var tokenRoutes=require("./routes/generateTableauTokenNew")
//app.use("/stategy",stategyRoutes)

app.use("/employee", employeeRoutes)
//app.use("/token",tokenRoutes)
app.use("/domain", domainRoutes)


db.sequelize.authenticate().then(function () {

  app.listen(PORT, () => console.log(`Server running on port: http://localhost:${PORT}`));

  console.log("Connected to read/write database !!!");

}).catch(function (err) {

  console.log(err, "err from DB sequalize authenticate function >>>>>>>>>")

  console.log("Some error occured", err);

})