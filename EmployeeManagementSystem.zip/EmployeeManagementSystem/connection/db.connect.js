'use strict'
const Sequelize = require('sequelize');
const dbDebugger = require('debug')('app:db');
Sequelize.DATE.prototype._stringify = function _stringify(date, options) {
    return this._applyTimezone(date, options).format('YYYY-MM-DD HH:mm:ss.SSS');
};
const op = Sequelize.Op;
const dbConfig = require('./db.config');
//const toBoolean = require('yn');
const sequelize = new Sequelize(dbConfig.database, dbConfig.username, dbConfig.password, {
    host: dbConfig.host,
    port: dbConfig.port,
    dialect: dbConfig.dialect,
    dialectOptions: dbConfig.dialectOptions,
    define: {
        underscored: true,
        timestamps: false,
        hierarchy: true
    },
    pool: {
        max: 35,
        min: 0,
        acquire: 30000,
        idle: 60000
    }
});
dbDebugger("Sequelize connection object created:", sequelize.config);
console.log("Sequelize connection object created:", sequelize.config)
const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.op = op;
db.config = dbConfig;


/*
db.userrolesTable = require("../models/userrolesTable")(
    sequelize,
    Sequelize
)
*/
db.UserSchema = require("../models/userrolesTable")(
    sequelize,
    Sequelize
)

db.projectTable = require("../models/projectTable")(
    sequelize,
    Sequelize
);



db.employeeTable = require("../models/employeeTable")(
    sequelize,
    Sequelize
);


db.mastdomainTable = require("../models/mastdomainTable")(
    sequelize,
    Sequelize
);

db.mastProjectStatusTable = require("../models/mastProjectStatusTable")(
    sequelize,
    Sequelize
)

db.projectTable.hasMany(db.employeeTable, {
    //foreignKey: "EmployeeID",
});

db.employeeTable.belongsTo(db.projectTable, {
    foreignKey: "EmployeeID",
});

db.mastdomainTable.hasMany(db.employeeTable, {
    foreignKey: "EmployeeID"
})

db.employeeTable.belongsTo(db.mastdomainTable, {
    foreignKey: "EmployeeID"
})

module.exports = db