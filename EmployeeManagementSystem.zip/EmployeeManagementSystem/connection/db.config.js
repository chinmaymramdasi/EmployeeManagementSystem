/*const { createPool } = require("mysql");

const db = createPool({
  port: 3306,
  host: "localhost",
  user: "root",
  password: "ind123",
  database: "syscovphr",
  connectionLimit: 10,
});


module.exports = db;
*/const { createPool } = require("mysql");






const dbConfig = {

  host: "localhost",

  password:"ind123",
  username: 'root',
  database: "sample",

  dialect: "mysql",

  dialectOptions: {

  "options": {

  encrypt: 0,

  database: "sample",

  requestTimeout: 30000,

  connectTimeout: 60000

  }

  

  }

  }

module.exports = dbConfig