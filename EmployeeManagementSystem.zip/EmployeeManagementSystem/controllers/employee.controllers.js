const { Container } = require("winston")
const { username } = require("../connection/db.config")
const db = require("../connection/db.connect")
const { connect } = require("../routes/employee.routes")
//import {viewEmployeeList,viewObj,viewProjectList} from "../utils/generalfunctions"
const { viewObj, viewEmployeeList, viewProjectList, getDetails, viewDomainEmployeeList, generateWhereQuery } = require("../utils/generalfunctions")
//import {logger} from "../loggers/logger"
const { logger } = require("../loggers/logger")



const EmployeeController = {

  createEmployee: async function (req, res) {
    try {
      let { employeeID, employeeName, designation, location, domainID } = req.body

      let data = await db.employeeTable.create({
        employeeID,
        employeeName,
        designation,
        location,
        domainID
      })


      res.json({
        success: 200,
        msg: "New employee added successfully"
      })
    }
    catch (error) {
      logger.log({
        level: "error",
        msg: `In Create API ${error.message}`,
        stack: error.stack
      })
      console.log(error)
    }
  },
  //GET API to call 2 conditions 
  //1. To fetch a particular value with respect to employee ID 
  //2. To fetch all the records of employee ID
  getEmployee: async function (req, res) {
    try {

      let employeeID = req.body.employeeID
      console.log("ID", employeeID)
      let whereQuery = generateWhereQuery(employeeID)
      console.log(whereQuery)
      if (employeeID && employeeID != null) {
        let sqlQuery = `select employee.EmployeeID,EmployeeName,Designation,Location,DomainName,ProjectStatus,
        ProjectName from employee join domain on employee.DomainID=domain.DomainID inner join projects on 
        employee.EmployeeID=projects.EmployeeID ${whereQuery}`

        let data = await db.sequelize.query(


          sqlQuery, {
          type: db.sequelize.QueryTypes.SELECT
        }

        )
        console.log("Data Fetch By ID", data)
        data.sort()
        res.json(data)

        //console.log("With employee ID",data1)    
      }
      else {
        let sqlQuery = `select employee.EmployeeID,EmployeeName,Designation,Location,DomainName,ProjectName,ProjectStatus from employee join domain on employee.DomainID=domain.DomainID inner join projects on employee.EmployeeID=projects.EmployeeID`

        let data = await db.sequelize.query(


          sqlQuery, {

          type: db.sequelize.QueryTypes.SELECT

        }

        )

        console.log("Data Fetch", data)

        data.sort()
        //console.log(data1)
        res.json(data)
      }

      //console.log(data)


    }
    catch (error) {
      logger.error({
        msg: `In Get Employee API ${error.message}`
      })
      console.log(error)
    }
  },
  //GET API to fetch employees under a particular project assigned to them.

  fetchEmployeeByProject: async function (req, res) {
    try {
      let projectName = req.body.projectName
      let query = `select count(*) as employeecount from employee as e join projects as p on e.EmployeeID=p.EmployeeID where p.ProjectName=?`

      let data1 = await db.sequelize.query(


        query, {
        replacements: [projectName],
        type: db.sequelize.QueryTypes.SELECT

      }

      )

      console.log("employee count per project", data1)


      let sqlQuery = `select employee.EmployeeID,EmployeeName,ProjectName from employee JOIN projects ON employee.EmployeeID=projects.EmployeeID where projects.ProjectName=?`
      let data = await db.sequelize.query(


        sqlQuery, {
        replacements: [projectName],
        type: db.sequelize.QueryTypes.SELECT
      }

      )

      array = []
      view = {}
      for (let subdata of data) {
        var index = array.findIndex(function (results) {
          return results.projectname == subdata.ProjectName
        })


        if (index > -1) {
          view = viewEmployeeList(subdata)
          array[index]['employeelist'].push(view)
        }
        else {
          view = viewEmployeeList(subdata)
          array.push({
            'projectname': subdata.ProjectName,
            'employeelist': [view]

          })
        }
      }
      console.log(array)
      /*
      Object.keys(data).forEach(function (item) {
        let container={}
        container.employeeName=`${data[item].EmployeeName}`
        container.projectassigned=`${data[item].ProjectName}`
      
        console.log(container)
        return container
      })
      */
      //console.log(container)
      //console.log(data)
      let obj = Object.assign({}, ...data1)  // spread operator
      let d = { ...obj, ...array[0] }
      console.log("Formatted res", d)
      res.json(d)
    }
    catch (error) {
      logger.error({
        msg: `In fetchEmployeeByProject API ${error.message}`,
        stack: error.stack
      })
      console.log(error)
    }
  },

  fetchProjectsofEmployee: async function (req, res) {
    try {
      let employeeName = req.body.employeeName
      let employeeId = req.body.employeeID
      let sqlQuery = `select employee.EmployeeID,EmployeeName,ProjectName from employee JOIN projects ON employee.EmployeeID=projects.EmployeeID where employee.EmployeeName=? or employee.EmployeeID=?`
      let data = await db.sequelize.query(


        sqlQuery, {
        replacements: [employeeName, employeeId],
        type: db.sequelize.QueryTypes.SELECT

      }

      )

      debugger

      array = []
      view = {}
      for (let subdata of data) {
        var index = array.findIndex(function (results) {
          return results.employeeName == subdata.EmployeeName
        })

        if (index > -1) {
          view = viewProjectList(subdata)
          array[index]['projectassigned'].push(view)
        }
        else {
          view = viewProjectList(subdata)
          array.push({
            'employeeName': subdata.EmployeeName,
            'projectassigned': [view]
          })
        }
      }

      /*
      Object.keys(data).forEach(function (item) {
        let container={}
        container.employeeName=`${data[item].EmployeeName}`
        container.projectassigned=`${data[item].ProjectName}`
      
        console.log(container)
        return container
      })
      */
      //console.log(container)
      console.log(array)
      res.json(array)
    }
    catch (error) {
      logger.error({
        msg: `In fetchProjectsofEmployee API ${error.message}`,
        stack: error.stack
      })
      console.log(error)
    }
  },
  updateEmployee: async function (req, res) {
    try {
      let { employeeID, ProjectStatus } = req.body
      let data = await db.employeeTable.update({
        ProjectStatus
      },
        {
          where: {
            employeeID
          }
        })

      res.json({
        success: 200,
        msg: "Employee Records Updated successfully"
      })
    }
    catch (error) {
      logger.error({
        msg: `In updateEmployee API ${error.message}`,
        stack: error.stack
      })
      console.log(error)
    }

  },
  deleteEmployee: async function (req, res) {
    try {
      let employeeID = req.body.employeeID
      let data = await db.employeeTable.destroy({
        where: {
          employeeID
        }
      })

      res.json({
        success: 200,
        msg: "Employee Details Deleted successfully"
      })
    }
    catch (error) {
      console.log(error)
    }

  },
  createProject: async function (req, res) {
    try {
      let { projectId, projectName, employeeID } = req.body
      let sqlQuery = await db.projectTable.create({
        projectId,
        projectName,
        employeeID
      })
      console.log(sqlQuery)
      res.json({
        success: 200,
        msg: "New project is added in the list"
      })



    } catch (error) {
      console.log(error)
    }

  },

  fetchEmployeeLocation: async function (req, res) {
    try {
      let location = req.body.location
      let data = await db.employeeTable.findAll({
        attributes: ["EmployeeName"],
        where: {
          location
        },
        raw: true
      })
      console.log(data)

      const arr = data.map((e) => e.EmployeeName)
      console.log(arr)
      res.status(200).json({ "EmployeeNames": [...arr] })

      // data.map((item) => item.EmployeeName)
      // res.json(data)
    }
    catch (e) {
      console.log(e)
    }
  },

  fetchDomainbyEmployee: async function (req, res) {
    try {
      let array = []
      let view = {}
      let sqlQuery = `select EmployeeName, DomainName from employee join domain on employee.DomainID=domain.DomainID `
      let data = await db.sequelize.query(sqlQuery, {
        type: db.sequelize.QueryTypes.SELECT
      })

      console.log(data)
      for (let subdata of data) {
        var index = array.findIndex(function (results) {
          return results.DomainName == "Internal"
        })
        console.log("FirstIndex", index)

        if (index > -1) {
          console.log(index)
          view = viewDomainEmployeeList(subdata)
          array[index]['EmployeeName'].push(view)
        }
        else {
          view = viewDomainEmployeeList(subdata)
          array.push({
            'DomainName': subdata.DomainName,
            'EmployeeName': [view]
          })
        }
      }

      for (let subdata of data) {
        var index = array.findIndex(function (results) {
          return results.DomainName == "AppDev"
        })
        if (index > -1) {
          console.log(index)
          view = viewDomainEmployeeList(subdata)
          array[index]['EmployeeName'].push(view)
        }
        else {
          view = viewDomainEmployeeList(subdata)
          array.push({
            'DomainName': subdata.DomainName,
            'EmployeeName': [view]
          })
        }
      }


      console.log(array)
      res.json(array)
    }
    catch (e) {
      console.log(e)
    }
  },

  fetchEmployeeListByDomain: async function (req, res) {
    //select EmployeeName from employee inner join domain on employee.DomainID=domain.DomainID where DomainName="AppDev"
    try {
      let domainName = req.body.DomainName
      let promiseArray = []
      if (domainName) {
        let EmployeeListCount = `select count(EmployeeName) as EmployeeCount from employee inner join domain on employee.DomainID=domain.DomainID where DomainName='${domainName}'`
        promiseArray.push(db.sequelize.query(
          EmployeeListCount, {
          type: db.sequelize.QueryTypes.SELECT
        }
        ))

        let EmployeeFetchQuery = `select EmployeeName from employee inner join domain on employee.DomainID=domain.DomainID where DomainName='${domainName}'`
        promiseArray.push(db.sequelize.query(
          EmployeeFetchQuery, {
          type: db.sequelize.QueryTypes.SELECT
        }
        ))
        let data = await Promise.all(promiseArray)

        return res.json({
          EmployeeListcount: data[0][0].EmployeeCount,
          EmployeeList: [...data[1].map((e) => e.EmployeeName)]
        })
      }
      else {
        return res.json({
          error: 417,
          message: "Please enter Domain Name to get the employee List"
        })
      }
    }
    catch (e) {
      console.log(e)
    }
  }
}

module.exports = EmployeeController