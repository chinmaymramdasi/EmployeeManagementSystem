const { username } = require("../connection/db.config")
const db = require("../connection/db.connect")
const { connect } = require("../routes/projects.routes")
const { deleteEmployee } = require("./employee.controllers")
const { viewEmployeeListDetails } = require("../utils/generalfunctions")
const { sequelize } = require("../connection/db.connect")


const ProjectController = {

    createProject: async function (req, res) {
        try {
            let { projectID, projectName, employeeID } = req.body
            let data = await db.projectTable.create({
                projectID,
                projectName,
                employeeID
            })
            res.json({
                success: 200,
                msg: "New project is added in the list"
            })



        } catch (error) {
            console.log(error)
        }

    },
    updateProject: async function (req, res) {
        try {
            let employeeID = req.body.employeeID
            let projectId = req.body.projectId
            //let sqlQuery=`update projects set EmployeeID='${employeeID}' where ProjectID='${projectId}'`

            let data = await db.projectTable.update({
                employeeID
            },
                {
                    where: {
                        projectId
                    }
                }
            )
            res.json({
                success: 200,
                msg: `Employee ID updated sucessfully for Project ID='${projectId}'`
            })


        }
        catch (error) {
            console.log(error)
        }
    },
    getProjectDetails: async function (req, res) {
        try {
            let array = []
            let view = {}
            let sqlQuery = `select ProjectID, ProjectName, EmployeeName from projects LEFT JOIN employee ON projects.EmployeeID=employee.EmployeeID`

            let data = await db.sequelize.query(sqlQuery,
                {
                    type: db.sequelize.QueryTypes.SELECT
                }
            )

            for (let subdata of data) {
                var index = array.findIndex(function (results) {
                    return results.projectId == subdata.ProjectID
                })

                if (index > -1) {
                    view = viewEmployeeListDetails(subdata)
                    array[index]['employeeName'].push(view)
                }
                else {
                    view = viewEmployeeListDetails(subdata)

                    array.push({
                        'projectId': subdata.ProjectID,
                        'projectName': subdata.ProjectName,
                        'employeeName': [view]
                    })
                }
            }



            console.log(array)

            res.json(array)
        }
        catch (err) {
            console.log(err)
        }
    },
    deleteEmployee: async function (req, res) {
        try {
            let employeeID = req.body.employeeID
            let data = await db.employeeTable.destroy({
                where: {
                    employeeID
                }
            })
            res.json({
                success: 200,
                msg: `Employee '${employeeID}' is removed from the assigned project`
            })


        }
        catch (error) {
            console.log(error)
        }
    },
    getProject: async function (req, res) {
        try {
            let data = await db.projectTable.findAll({
                attributes: [[db.Sequelize.fn('DISTINCT', db.Sequelize.col('ProjectName')), 'projectName']]
            })
            let container = []
            container.push(...data.map((e) => e.projectName))
            res.json({ ProjectList: container.sort() })

        }
        catch (error) {
            console.log(error)
        }
    },
    getProjectStatus: async function (req, res) {
        try {
            let data = await db.mastProjectStatusTable.findAll({})

            console.log(data)
            res.json(data)
        }
        catch (e) {
            console.log(e)
        }
    },
    deleteProject: async function (req, res) {
        try {
            let projectName = req.body.projectName
            if (projectName) {
                let deleteProject = await db.projectTable.destroy({
                    where: { projectName: projectName }
                })

                res.json({
                    status: 200,
                    msg: `${projectName} Project is been deleted from the Project List`
                })
            }
            else {
                res.json({
                    status: 404,
                    msg: `Please put the projectName that needs to be deleted`
                })
            }
        }
        catch (e) {
            console.log(e)
        }

    }

}

module.exports = ProjectController