const jwt = require("jsonwebtoken");
const Role = require("../utils/role")
const db = require("../connection/db.connect")
const brcypt = require("bcryptjs")

let config = "test!212"

const UserController = {
    authenticate: async function (req, res) {
        let employeeName = req.body.employeeName
        let password = req.body.password

        let responsedata = await db.UserSchema.findOne({
            raw: true,
            where: { employeeName }
        })
        //console.log(user)

        if (await db.UserSchema.build().validPassword(password, responsedata.password)) {
            const token = jwt.sign({ sub: responsedata.email, role: responsedata.role }, config);
            return res.json({
                status: true,
                token,
                roleAccess: responsedata.role
            })
        }
        else {
            return res.json({
                status: false,
                message: "Invalid password"
            })
        }
    },
    createUser: async function (req, res) {
        let { employeeName, email, password } = req.body

        let hashedpassword = await brcypt.hash(password, 8)
        let createUser = await db.UserSchema.create({
            employeeName,
            email,
            password: hashedpassword
        })
        console.log(createUser)
        return res.json({
            status: 200,
            msg: "User created successfully!!!"
        })
    }
}

module.exports = UserController
