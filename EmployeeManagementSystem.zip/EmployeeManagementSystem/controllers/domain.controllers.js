const { username } = require("../connection/db.config")
  const db =require("../connection/db.connect")
  const { connect } = require("../routes/domain.routes")



  const DomainController= {
    
    getDomainList: async function (req, res) {
          try {
             var data=await db.mastdomainTable.findAll({
              raw:true
             })
             console.log(data)
             const cust = data.map(function (item) {
              let result = Object.keys(item).map((key) => item[key]);
              return result;
          });
          res.json(cust)
          }
          catch (e) {
              console.log(e)
          }
      },

      

}


module.exports=DomainController