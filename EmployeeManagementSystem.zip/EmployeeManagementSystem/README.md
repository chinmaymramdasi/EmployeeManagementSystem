# EmployeeManagementSystem
Employee Management System to monitor to employee activities during the work life cycle
