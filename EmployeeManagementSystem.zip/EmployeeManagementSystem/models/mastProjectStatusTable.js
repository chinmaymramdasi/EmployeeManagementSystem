const { DataTypes } = require("sequelize");

module.exports = function (sequelize, Sequelize) {
    return sequelize.define(
        "mastProjectStatusTable",
        {
            projectstatusID: {
                type: DataTypes.BIGINT,
                field: "ProjectID",
                primaryKey: true,
                autoincrement:true
            },
            status: {
                type: DataTypes.STRING,
                field: "Status",
            },
        },
        {
            freezeTableName: true,

            timestamps: false,

            tableName: "projectstatus",
        }
    );
};
