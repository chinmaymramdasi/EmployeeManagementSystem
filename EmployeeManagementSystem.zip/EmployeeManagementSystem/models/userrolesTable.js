const { DataTypes } = require("sequelize");
const { userrolesTable } = require("../connection/db.connect");
const bcrypt = require("bcryptjs")

module.exports = function (sequelize, Sequelize) {
    var userSchema = sequelize.define(
        "userrolesTable",
        {
            employeeName: {
                type: DataTypes.STRING,
                field: "EmployeeName",
                required: true,
                primaryKey: true,
            },
            email: {
                type: DataTypes.STRING,
                field: "email",
                validate: {
                    isEmail: true
                },
                isUnique: true
            },
            password: {
                type: DataTypes.STRING,
                field: "password",
                isUnique: true
            },
            role: {
                type: DataTypes.STRING,
                field: "role",
                enum: ["user", "admin"],
                default: "user"
            }
        },
        {
            freezeTableName: true,

            timestamps: false,

            tableName: "users",

            instanceMethods: {
                generateHash(password) {
                    return bcrypt.hash(password, bcrypt.genSaltSync(8));
                },
                validPassword(password) {
                    console.log(bcrypt.compare(password, this.password))
                    return bcrypt.compare(password, this.password);
                }
            }
        }

    );
    userSchema.prototype.validPassword = async (password, hash) => {
        return await bcrypt.compare(password, hash);
    }
    return userSchema
};