const { DataTypes } = require("sequelize");

module.exports = function (sequelize, Sequelize) {
    return sequelize.define(
        "projectTable",
        {
            projectID: {
                type: DataTypes.BIGINT,
                field: "ProjectID",
                primaryKey: true,
            },
            projectName: {
                type: DataTypes.STRING,
                field: "ProjectName",
            },
            employeeID: {
                type: DataTypes.INTEGER,
                field: "EmployeeID",
                references:{
                    model:"employee",
                    key:"EmployeeID"
                }
            },
        },
        {
            freezeTableName: true,

            timestamps: false,

            tableName: "projects",
        }
    );
};
