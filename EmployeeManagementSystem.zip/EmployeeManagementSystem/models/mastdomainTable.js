const { DataTypes } = require("sequelize");

module.exports = function (sequelize, Sequelize) {
    return sequelize.define(
        "mastdomainTable",
        {
            domainID: {
                type: DataTypes.BIGINT,
                field: "DomainID",
                primaryKey: true,
            },
            domainName: {
                type: DataTypes.STRING,
                field: "DomainName",
            },
        },
        {
            freezeTableName: true,

            timestamps: false,

            tableName: "domain",
        }
    );
};
