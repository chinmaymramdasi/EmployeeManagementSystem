const { DataTypes } = require("sequelize");

module.exports = function (sequelize, Sequelize) {
    return sequelize.define(
        "employeeTable",
        {
            employeeID: {
                type: DataTypes.BIGINT,
                field: "EmployeeID",
                primaryKey: true,
            },
            employeeName: {
                type: DataTypes.STRING,
                field: "EmployeeName",
            },
            designation: {
                type: DataTypes.STRING,
                field: "Designation",
            },
            domainID: {
                type: DataTypes.BIGINT,
                field: "DomainID",
                references: {
                    model: "domain",
                    key: "DomainID"
                }
            },
            location: {
                type: DataTypes.STRING,
                field: "Location",
            },
            ProjectStatus: {
                type: DataTypes.STRING,
                field: "ProjectStatus"
            }
        },
        {
            freezeTableName: true,

            timestamps: false,

            tableName: "employee",

        }
    );
};
