
const {createLogger,format,transports} = require('winston')
const { combine, timestamp, printf } = format;

const myFormat = printf(({ level, message, timestamp }) => {
    return `${timestamp} ${level}: ${message}`;
  });


const myWinstonOptions = {
   transports: [new transports.File({filename:"error.log",level:"error"})],
}

const logger =createLogger({
    format: combine(
    timestamp(),
    myFormat
    ),
    myWinstonOptions})



module.exports={
    logger
}