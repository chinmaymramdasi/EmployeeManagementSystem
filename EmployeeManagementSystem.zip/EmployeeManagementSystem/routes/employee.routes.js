var employeecontroller = require("../controllers/employee.controllers")

//const authController = require('../controllers/authController')
var Role = require("../utils/role")
var authorize = require("../utils/authorize")
var express = require("express")

var router = express.Router()

router.post("/createEmployee", authorize(Role.Admin), employeecontroller.createEmployee)
//router.route('/getEmployee').get(authController.protect, authController.restictTo('admin'), employeecontroller.getEmployee);
router.get("/getEmployee", authorize(Role.User, Role.Admin), employeecontroller.getEmployee)
router.put("/updateEmployee", authorize(Role.User), employeecontroller.updateEmployee)
router.delete("/deleteEmployee", authorize(Role.Admin), employeecontroller.deleteEmployee)
router.get("/fetchEmployeeByProject", authorize(Role.User), employeecontroller.fetchEmployeeByProject)
router.get("/fetchProjectsofEmployee", authorize(Role.User), employeecontroller.fetchProjectsofEmployee)
router.get("/fetchEmployeeByLocation", authorize(Role.User), employeecontroller.fetchEmployeeLocation)
router.get("/fetchDomainEmployee", authorize(Role.User, Role.Admin), employeecontroller.fetchDomainbyEmployee)
router.get("/fetchEmployeeListByDomain", authorize(Role.Admin), employeecontroller.fetchEmployeeListByDomain)


//router.get("/gettoken",strategycontroller.gettoken)


module.exports = router