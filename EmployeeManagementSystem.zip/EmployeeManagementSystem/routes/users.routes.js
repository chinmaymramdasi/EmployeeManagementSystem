let usercontroller = require("../controllers/users.controllers")

let express = require("express")

//let authorize = require("../utils/authorize")


let router = express.Router()

router.post('/authenticate', usercontroller.authenticate);     // public route
router.post('/createUser', usercontroller.createUser)
// router.get('/', authorize(Role.Admin), usercontroller.getAll); // admin only
// router.get('/:id', authorize(), usercontroller.getById);


module.exports = router
