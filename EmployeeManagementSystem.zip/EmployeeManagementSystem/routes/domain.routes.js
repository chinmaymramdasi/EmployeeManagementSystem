var domainController = require("../controllers/domain.controllers")

var express = require("express")

let authorize = require("../utils/authorize")

let Role = require("../utils/role")
var router = express.Router()


router.get("/getDomainList", authorize(Role.Admin), domainController.getDomainList)



module.exports = router