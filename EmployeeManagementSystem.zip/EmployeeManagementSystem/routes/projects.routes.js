let projectcontroller = require("../controllers/projects.controllers")
let Role = require("../utils/role")
let express = require("express")
let authorize = require("../utils/authorize")



let router = express.Router()

router.post("/createProject", authorize(Role.Admin), projectcontroller.createProject)
router.put("/updateProject", authorize(Role.Admin), projectcontroller.updateProject)
router.get("/fetchProjectsDetails", authorize(Role.User, Role.Admin), projectcontroller.getProjectDetails)
router.delete("/deleteEmployeefromProject", authorize(Role.Admin), projectcontroller.deleteEmployee)
router.get("/getProjectList", authorize(Role.User, Role.Admin), projectcontroller.getProject)
router.get("/getProjectStatus", authorize(Role.User), projectcontroller.getProjectStatus)
router.delete("/deleteProjectInfo", authorize(Role.Admin), projectcontroller.deleteProject)


module.exports = router